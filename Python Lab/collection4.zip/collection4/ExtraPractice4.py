# ExtraPractice4 ทำเกี่ยวกับยอดรวมคนติดโควิด-19แต่ละประเทศในเอเซียเช็คผลรวมล่าสุดวันที่ 14/12/2020
import requests
import json  # list,dictionary

url = "https://opendata.ecdc.europa.eu/covid19/casedistribution/json/"
r = requests.get(url)
myData = json.loads(r.content)
# print("{}".format(myData))
# print("{}".format(type(myData)))
ncountry = ""
ctotal = 0
n = 1
print("\tCovid-19 in Asia each country 14/12/2020")
for i in myData["records"]:
    if i["continentExp"] == "Asia":
        if i["countriesAndTerritories"] == ncountry:
            ctotal += i["cases"]
        else:
            if ncountry != "" and ctotal != 0:
                print("{:>2}.) Name : {:22} cases : {:>9,}".format(n, ncountry, ctotal))
                n += 1
            ctotal = i["cases"]
            ncountry = i["countriesAndTerritories"]
