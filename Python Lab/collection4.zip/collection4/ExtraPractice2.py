# ExtraPractice2
import requests
import json  # list,dictionary

url = "https://data.go.th/dataset/84954e4a-3302-4b05-9dfc-c636f30b62ab/resource/31ddd8a7-c99a-43eb-8c2e-9644ddb1608b/download/university.json"
r = requests.get(url)
myData = json.loads(r.content)
# print("{}".format(myData))
# print("{}".format(type(myData)))

count = 1
for i in myData["features"]:
    if i["properties"]["type"] == '3':
        print("{}.) {} {}".format(count, i["properties"]["name"], i["properties"]["web"]))
        count = count + 1
