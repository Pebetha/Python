# ExtraPractice3
import requests
import json  # list,dictionary

url = "https://data.go.th/dataset/ee189de7-7131-4808-8c69-de101c0bd0e4/resource/7dcc70f4-b03d-4cdd-b2ce-d0b5fc66b91e/download/train_station.json"
r = requests.get(url)
myData = json.loads(r.content)
# print("{}".format(myData))
# print("{}".format(type(myData)))

count = 1
for i in myData["features"]:
    if i["properties"]["type"] == '1':
        print("{:3}.) {}".format(count, i["properties"]["name"]))
        if i["properties"]["tel"] == '-' or i["properties"]["tel"] == "":
            print("\t  เบอร์โทร ไม่มี")
        else:
            print("\t  เบอร์โทร {}".format(i["properties"]["tel"]))
        count = count + 1
