# pracSqlExtra12


import sqlite3


def Showsales(db, sales):
    with (sqlite3.connect(db)) as conn:
        conn.row_factory = sqlite3.Row
        sqlcommand = '''
        SELECT P.ProductId,ProductName
        FROM OrdersDetails o JOIN Products p 
        on o.ProductId = p.ProductId
        GROUP by P.ProductId
        HAVING count(OrderId) > ?
        '''
        cursor = conn.execute(sqlcommand, sales)
        found = len(conn.execute(sqlcommand, sales).fetchall())
        print("Found = {}".format(found))
        print("-" * 25)
        print("รหัส สินค้า")
        print("-" * 25)
        for i in cursor:
            print("{:2}  {}".format(i[0], i[1]))


input = int(input("กรอกจํานวนที่สินค้าขายได้มากกว่ากี่ครั้ง : "))
stime = [input]
databasename = 'myDatabase/Sqlite_Northwind.sqlite3'
Showsales(databasename, stime)
