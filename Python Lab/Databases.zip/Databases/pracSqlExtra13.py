# pracSqlExtra13


import sqlite3


def InsertCustomer(db, values):
    with(sqlite3.connect(db)) as conn:
        sqlcommand = '''insert into Customers
            values (?,?,?,?,?,?,?,?,?,?,?)
            '''
        conn.execute(sqlcommand, values)
        conn.commit()
        print("You Infomation has been successfully added")


print("-" * 50)
print("\t\t\tADDING NEW CUSTOMER")
print("-" * 50)
cid = input("Please Input Company Id")
companyname = input("Please Input Company name : ")
contactname = input("Please Input Contact name : ")
contacttitle = input("Please Input Contact Title : ")
address = input("Please Input Address : ")
city = input("Please Input Company city : ")
region = input("Please Input Contact Region : ")
postal = input("Please Input Contact Postal code : ")
country = input("Please Input Country : ")
phone = input("Please Input Phone : ")
fax = input("Please Input Fax : ")

databasename = 'myDatabase/Sqlite_Northwind.sqlite3'
values = [cid, companyname, contactname, contacttitle, address, city, region, postal, country, phone, fax]

InsertCustomer(databasename, values)
