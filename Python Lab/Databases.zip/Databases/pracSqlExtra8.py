# pracSqlExtra8


import sqlite3


def ShowCustomer(db):
    with (sqlite3.connect(db)) as conn:
        conn.row_factory = sqlite3.Row
        sqlcommand = '''
        SELECT CompanyName,CategoryName,count(ProductName),avg(UnitPrice)
        FROM Products p JOIN Suppliers s on 
        s.SupplierId = p.SupplierId JOIN
        Categories c on p.CategoryId = c.CategoryId
        GROUP By CompanyName
        '''
        cursor = conn.execute(sqlcommand)

        for i, v in enumerate(cursor):
            print("{} ({}) No. of Product = {} (Average price = {:.2f})".format(v[0], v[1], v[2], v[3]))


databasename = 'myDatabase/Sqlite_Northwind.sqlite3'
ShowCustomer(databasename)
