# pracSqlExtra7


import sqlite3


def ShowEmployee(db):
    with (sqlite3.connect(db)) as conn:
        conn.row_factory = sqlite3.Row
        sqlcommand = '''SELECT FirstName||' '||LastName||' , '||TitleOfCourtesy,count(OrderId)
                        FROM Employees e JOIN Orders o
                        on e.EmployeeId = o.EmployeeId
                        GROUP by FirstName
                        order by count(OrderId)
        '''
        cursor = conn.execute(sqlcommand)

        for i, v in enumerate(cursor):
            print("{}.){:25}{:15}".format(i + 1, v[0], v[1], ))


databasename = 'myDatabase/Sqlite_Northwind.sqlite3'
ShowEmployee(databasename)
