# pracSqlExtra1


import sqlite3


def Checkcategory(db, ct):
    with (sqlite3.connect(db)) as conn:
        conn.row_factory = sqlite3.Row
        sqlcommand = '''SELECT ProductName,UnitPrice
            FROM Products p join Categories c 
            on p.CategoryId = c.CategoryId
            WHERE lower(CategoryName) = lower(?)
            ORDER by ProductName
        '''
        cursor = conn.execute(sqlcommand, ct)
        found = len(conn.execute(sqlcommand, ct).fetchall())
        print("{} Found {} Record(s)".format(ct[0], found))
        for n, i in enumerate(cursor):
            print("{:2}.) {:40} : {:6.2f} Baht".format(n + 1, i[0], i[1]))


selectct = input("Enter your category name to see : ")
print("")
ct = [selectct.lower()]
databasename = 'myDatabase/Sqlite_Northwind.sqlite3'
Checkcategory(databasename, ct)
