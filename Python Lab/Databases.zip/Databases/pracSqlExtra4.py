# pracSqlExtra4


import sqlite3


def Checkcategory(db):
    with (sqlite3.connect(db)) as conn:
        conn.row_factory = sqlite3.Row
        sqlcommand = '''SELECT Region,count(DISTINCT Country),count(DISTINCT City)
                        from Customers
                        GROUP by Region
                        ORDER by count(DISTINCT City) DESC;
        '''
        cursor = conn.execute(sqlcommand)
        print("Show Customers by Region")
        print('-' * 60)
        print("Region                         Country               City")
        print('-' * 60)
        for i in cursor:
            print("{:15}{:20}{:21}".format(i[0], i[1], i[2]))


databasename = 'myDatabase/Sqlite_Northwind.sqlite3'
Checkcategory(databasename)
