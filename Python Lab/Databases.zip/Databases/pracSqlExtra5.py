# pracSqlExtra5


import sqlite3


def sql(db, stock):
    with (sqlite3.connect(db)) as conn:
        conn.row_factory = sqlite3.Row
        sqlcommand = '''
        SELECT ProductId,ProductName,UnitPrice * UnitsInStock
        FROM Products
        WHERE UnitPrice * UnitsInStock  > ?

        '''
        currsor = conn.execute(sqlcommand, stock)

        for i in currsor:
            print("ID = {}".format(i[0]))
            print("PRODUCT NAME = {}".format(i[1]))
            print("STOCK VALUE = {:,.2f}".format(i[2]))
            print("-" * 40)


input = int(input("Input Stock value you want to see more than (UnitPrice * UnitsInStock) : "))
print("")
databasename = 'myDatabase/Sqlite_Northwind.sqlite3'
stock = [input]
sql(databasename, stock)
