# pracSqlExtra11


import sqlite3


def Showorder(db):
    with (sqlite3.connect(db)) as conn:
        conn.row_factory = sqlite3.Row
        sqlcommand = '''
       SELECT ProductId,ProductName,UnitPrice,UnitPrice-(SELECT avg(UnitPrice)
													FROM Products)
        FROM Products
        WHERE UnitPrice > (SELECT avg(UnitPrice)
					FROM Products)
        ORDER by UnitPrice DESC

        '''
        cursor = conn.execute(sqlcommand)
        print("Show Customers by sales")
        print("-" * 85)
        print("รหัส  สินค้า\t\t\t\t\t\t\t\t\t\t\tราคาสินค้า \t\t\tราคาสูงกว่าค้าเฉลี่ย")
        print("-" * 85)
        for i, v in enumerate(cursor):
            print("{:2}   {:32} {:20,.2f} {:20,.2f}".format(v[0], v[1], v[2], v[3]))
        print("-" * 85)


databasename = 'myDatabase/Sqlite_Northwind.sqlite3'
Showorder(databasename)
