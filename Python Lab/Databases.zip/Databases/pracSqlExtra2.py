# pracSqlExtra2


import sqlite3


def sql(db, values, sort):
    with (sqlite3.connect(db)) as conn:
        conn.row_factory = sqlite3.Row
    sqlcommand = '''SELECT ProductName,UnitPrice
                FROM Products
                WHERE UnitPrice BETWEEN ? and ?
                ORDER by UnitPrice  ;

    '''
    sqlcommand2 = '''SELECT ProductName,UnitPrice
                   FROM Products
                   WHERE UnitPrice BETWEEN ? and ?
                   ORDER by UnitPrice DESC ;

       '''
    if sort == 1:
        cursor = conn.execute(sqlcommand, values)
    else:
        cursor = conn.execute(sqlcommand2, values)

    found = len(conn.execute(sqlcommand, values).fetchall())
    print("Found {} Record(s)".format(found))
    for n, i in enumerate(cursor):
        print("{:2}.) {:40} : {:6.2f} Baht".format(n + 1, i[0], i[1]))


startp = int(input("Enter start price you want to see : "))
endp = int(input("Enter end price you want to see : "))

while endp <= startp:
    print(">> End price should be more than Start price <<")
    startp = int(input("Enter start price you want to see : "))
    endp = int(input("Enter end price you want to see : "))

print("Sort price : [1] Ascending [2] Descending")
selectsort = int(input("Select [1] or [2] : "))
print("")
values = [startp, endp]
databasename = 'myDatabase/Sqlite_Northwind.sqlite3'
sql(databasename, values, selectsort)
