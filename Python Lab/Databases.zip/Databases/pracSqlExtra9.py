# pracSqlExtra9


import sqlite3


# CREATE VIEW OrderSummary as
# SELECT o.OrderId,OrderDate,c.CompanyName,ProductName,od.UnitPrice*od.Quantity as Price,s.CompanyName
# FROM Orders o JOIN Customers c on
# o.CustomerId = c.CustomerId
# JOIN Shippers s on o.ShipVia = s.ShipperID
# JOIN OrdersDetails od on o.OrderId = od.OrderId
# JOIN Products p on od.ProductId = p.ProductId;


def Showorder(db, values):
    with (sqlite3.connect(db)) as conn:
        conn.row_factory = sqlite3.Row
        sqlcommand = '''
        SELECT * 
        FROM OrderSummary
        WHERE OrderId = ?
        order by productname
        '''
        cursor = conn.execute(sqlcommand, values)
        od = cursor.fetchall()
        totalprice = 0

        print("Order ID   : {}".format(values[0]))
        print("Order Date : {}".format(od[0][1]))
        print("Customer   : {}".format(od[0][2]))
        print("-" * 51)
        for i, v in enumerate(od):
            print("{}.) {:38} {:>8,.2f}".format(i + 1, v[3], v[4]))
            totalprice = totalprice + float(v[4])
        print("-" * 51)
        vat7 = totalprice * 7 / 100
        print("\t\t\t\t\t\tTOTAL PRICE : {:>13,.2f}".format(totalprice))
        print("\t\t\t\t\t\tVAT (7%)    : {:>13,.2f}".format(vat7))
        print("\t\t\t\t\t\tNET PRICE   : {:>13,.2f}".format(totalprice + vat7))
        print("-" * 51)
        print("Send By : {}".format(od[0][5]))


order_id = input("กรุณากรอก Order ID ที่ต้องการดูข้อมูล : ")
databasename = 'myDatabase/Sqlite_Northwind.sqlite3'
values = [order_id]
Showorder(databasename, values)
