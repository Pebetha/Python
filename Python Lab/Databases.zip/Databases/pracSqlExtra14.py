# pracSqlExtra14


import sqlite3


def line():
    print("-" * 60)


def Setproduct(db, proid):
    with (sqlite3.connect(db)) as conn:
        conn.row_factory = sqlite3.Row
        sqlcommand = '''

        SELECT ProductName,UnitPrice,UnitsInStock
        FROM Products
        WHERE ProductId = ?

        '''
        sqlupdate = '''UPDATE Products
                       SET Discontinued = 1
                       WHERE ProductId = ?
                       '''

        cursor = conn.execute(sqlcommand, proid)
        found = len(conn.execute(sqlcommand, proid).fetchall())

        if found == 0:
            print("Product not found")
        line()
        for i in cursor:
            print("Product name : {}".format(i[0]))
            print("Stock        : {}".format(i[1]))
            print("Price        : {}".format(i[2]))
        line()
        ch = input("Do you want to Discontinued this product [yes/no]: ")
        while ch.lower() != 'yes' and ch.lower() != 'no':
            ch = input("ERROR input yes or no :")
        line()

        if ch.lower() == 'yes':
            conn.execute(sqlupdate, proid)
            conn.commit()
            print("Product has been changed")
        else:
            print("Product has not been changed")


pid = input("Input product ID :  ")
proid = [pid]
databasename = 'myDatabase/Sqlite_Northwind.sqlite3'
Setproduct(databasename, proid)
