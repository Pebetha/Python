# pracSqlExtra3


import sqlite3


def Checkcategory(db):
    with (sqlite3.connect(db)) as conn:
        conn.row_factory = sqlite3.Row
        sqlcommand = '''SELECT Country,count(CompanyName)
                        FROM Suppliers
                        GROUP BY Country
                        ORDER by count(CompanyName) DESC
        '''
        cursor = conn.execute(sqlcommand)
        print("Supplier From                                      NO.of Company")
        print('-' * 70)
        for i in cursor:
            print("{:15}   {:40} ".format(i[0], i[1]))


databasename = 'myDatabase/Sqlite_Northwind.sqlite3'
Checkcategory(databasename)
