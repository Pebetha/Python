# pracSqlExtra10


import sqlite3


def Showorder(db):
    with (sqlite3.connect(db)) as conn:
        conn.row_factory = sqlite3.Row
        sqlcommand = '''
       SELECT c.Country,count(o.OrderId),sum(((unitPrice*Quantity) - (unitPrice*Quantity*Discount)) * 1.07) ,sum(((unitPrice*Quantity) - (unitPrice*Quantity*Discount)) * 1.07) / count(od.OrderId) 
        FROM Orders o JOIN Customers c
        on o.CustomerId = c.CustomerId JOIN OrdersDetails od
        on o.OrderId = od.OrderId
        GROUP by c.Country
        ORDER by sum((UnitPrice*Quantity))/count(o.OrderId) DESC
        '''
        cursor = conn.execute(sqlcommand)
        print("Show Customers by Sales")
        print("-" * 75)
        print("Country\t\t\t\t\t\tNo.of Order\t\tNET Price  \t\t\tPrice/Order")
        print("-" * 75)
        for i, v in enumerate(cursor):
            print("{:12} {:20} {:20,.2f} {:20,.2f}".format(v[0], v[1], v[2], v[3]))


databasename = 'myDatabase/Sqlite_Northwind.sqlite3'
Showorder(databasename)
