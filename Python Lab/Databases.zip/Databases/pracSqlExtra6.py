# pracSqlExtra6


import sqlite3


def sql(db, stock):
    with (sqlite3.connect(db)) as conn:
        conn.row_factory = sqlite3.Row
        sqlcommand = '''
        SELECT CategoryName,count(ProductId),sum(UnitPrice*UnitsInStock)
        FROM Categories c JOIN Products p 
        on c.CategoryId = p.CategoryId
        GROUP by CategoryName
        having sum(UnitPrice*UnitsInStock) > ?
        order by sum(UnitPrice*UnitsInStock)
        '''
        currsor = conn.execute(sqlcommand, stock)
        found = len(conn.execute(sqlcommand, stock).fetchall())
        print("Found {} Category(s)".format(found))
        for i, v in enumerate(currsor):
            print("{:2}.) {:15} {:10} PD. {:15,.2f} Baht".format(i + 1, v[0], v[1], v[2]))


input = int(input("See Value of Stock by Category : "))
print("")
print("")
databasename = 'myDatabase/Sqlite_Northwind.sqlite3'
stock = [input]
sql(databasename, stock)
