# Slide93
print("Input Score")
midterm = int(input("Midterm(100 points -> 30%) : "))
final = int(input("Final(100 points -> 50%) : "))
homework = int(input("Homework(100 points -> 20%) : "))
total = (midterm * 30 / 100) + (final * 50 / 100) + (homework * 20 / 100)
if 100 >= total >= 97:
    grade = "A+"
elif total >= 93:
    grade = "A"
elif total >= 90:
    grade = "A-"
elif total >= 87:
    grade = "B+"
elif total >= 83:
    grade = "B"
elif total >= 80:
    grade = "B-"
elif total >= 77:
    grade = "C+"
elif total >= 73:
    grade = "C"
elif total >= 70:
    grade = "C-"
elif total >= 67:
    grade = "D+"
elif total >= 63:
    grade = "D"
elif total >= 60:
    grade = "D-"
elif 60 > total >= 0:
    grade = "F"
else:
    print("Error Please regrade")
    grade = "W"
print("Your grade : {}".format(grade))
