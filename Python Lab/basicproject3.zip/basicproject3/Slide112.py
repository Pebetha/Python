# Slide112
import NewLibraly as nl

i = int(input("Input i : "))
j = int(input("Input j : "))
n = int(input("Input N : "))
nl.line1("*", 80)
total = 0
for z in range(i, j + 1):
    total += ((z - 10) ** n) * z
    if z < j:
        print("(({}-10)^{}) x {} +".format(z, n, z), end=" ")
    if z == j:
        print("(({}-10)^{}) x {}".format(z, n, z))
print("Answer = {:.2f}".format(total))
nl.line1("*", 80)
