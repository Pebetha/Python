# function

def line1(ch, num):
    print(ch * num)


def line2():
    print('*' * 20)

def mul_tablbe(N, M):
    for i in range(N, M + 1, 1):
        for j in range(1, 13):
            print("{} x {} = {}".format(i, j, i * j))

        line2()
