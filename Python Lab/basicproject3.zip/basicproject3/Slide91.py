# if, comparison operator
# Slide91
import math
import NewLibraly as nl

nl.line1('*', 30)
print("\t\t\tMenu")
nl.line1('*', 30)
print("C or c Area of Circle")
print("S or s Area of Rectangle")
nl.line1('*', 30)
choice = input("Enter Your Choice : ")
if choice == 'C' or choice == 'c':
    nl.line1('*', 30)
    radius = float(input("Please Input Radius : "))
    area = math.pi * radius ** 2
    nl.line1('*', 30)
    print("AREA = {:.2f}".format(area))
    nl.line1('*', 30)
elif choice == 'S' or choice == 's':
    nl.line1('*', 30)
    width = float(input("Please Input Width : "))
    length = float(input("Please Input length : "))
    nl.line1('*', 30)
    area = width * length
    print("AREA = {:.2f}".format(area))
    nl.line1('*', 30)
else:
    print("Please input only  C or S")
    nl.line1('*', 30)
