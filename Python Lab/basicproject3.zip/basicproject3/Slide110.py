# Slide110
import NewLibraly as nl

price = float(input("Input Price of car : "))
depre = int(input("depreciation per year <%> : "))
year = int(input("Input How many year you want to see : "))
print("")
nl.line1('*', 70)
print("Price of car = {:,.2f}".format(price) + " BAHT ")
nl.line1('*', 70)

for i in range(1, year + 1, 1):
    reduce = (price * depre) / 100
    price = price - reduce
    print("After use {} Year : Reduce = {:,.2f} BAHT Price = {:,.2f} BAHT".format(i, reduce, price))
nl.line1('*', 70)
