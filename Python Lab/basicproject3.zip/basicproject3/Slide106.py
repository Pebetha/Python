# Slide106
import NewLibraly as nl
s = int(input("Input first number of multiplication table : "))
l = int(input("Input last number of multiplication  table : "))
nl.line2()
nl.mul_tablbe(s, l)
