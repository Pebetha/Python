# Slide108
import NewLibraly as nl

num = int(input("How many student in class : "))
nl.line1('*', 40)
max = 0  # max
min = 0  # min
sum = 0
count = 1
while count <= num:
    score = float(input("Enter score of student number {} :".format(count)))
    if count == 1:
        max = score
        min = score
    if score > max:
        max = score
    if score < min:
        min = score
    sum = sum + score
    count = count + 1
nl.line1('*', 40)
print("Average Score = {:.2f}".format(sum / num))
print("Max score = {:.2f}".format(max))
print("Min score = {:.2f}".format(min))
nl.line1('*', 40)
