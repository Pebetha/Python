#tuple ()
#list []
#set {}
scoreA = {10, 20, 30, 40, 50, 20, 30}
scoreB = {9,20,34,50,20,45,67,89,90}
print("A = {}".format(scoreA))
print("B = {}".format(scoreB))
print("{}".format(type(scoreA)))
print("Union = {}".format(scoreA | scoreB))
print("Intersection = {}".format(scoreA & scoreB))
print("Difference A-B = {}".format(scoreA - scoreB))
print("Difference B-A = {}".format(scoreB - scoreA))
print("Symantic Difference A-B = {}".format(scoreA ^ scoreB))
print("Symantic Difference B-A = {}".format(scoreB ^ scoreA))
