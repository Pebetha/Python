# Dictionary
# item --> key , values
student = {"Name": "Adisak", "Surename": "Suasaming",
           "Age": 45}
print("{} -- {}".format(student, type(student)))
print("Name = {}".format(student["Name"]))
student["Name"] = "Archirawit"
print("Name = {}".format(student["Name"]))
print("Name = {}".format(student))
student["NAME"] = "Archirawit"
print("Name = {}".format(student))
del student["NAME"]
print("Name = {}".format(student))
