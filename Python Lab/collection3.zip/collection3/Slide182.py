# Slide182
def checkprime(n):
    if n > 1:
        for i in range(2, n):
            if (n % i) == 0:
                return "Composite Number"
                break
        else:
            return "Prime Number"

    else:
        return "Prime Number"


def Types_of_integer(*number):
    number = set(number)
    number = number | number
    number = list(number)
    number = sorted(number)

    for i in number:
        print("{:3} : {:>5}".format(i, checkprime(i)))


Types_of_integer(10, 9, 22, 32, 45, 9, 2, 103, 71, 45)
Types_of_integer(49, 37, 14, 37)
