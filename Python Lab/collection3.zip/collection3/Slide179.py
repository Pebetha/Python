# Slide179
wantedskill = {"C#", "Python", "Java", "PHP", "SQL", "Go"}
applicant1skill = {"VB", "C", "Ruby", "Java", "HTML"}
applicant2skill = {"C#", "HTML", "R", "PHP", "SQL", "Swift", "PHP"}
applicant3skill = {"Java", "C++", "Ruby", "JavaScript", "Objective-C", "Go"}
applicant4skill = {"Java", "Python", "Go", "SQL", "Swift"}
applicant5skill = {"C++", "C", "C#", "Objective-C", "JavaScript", "SQL"}
print("Applicant 1 skill match : {:.2f}%".format(len(applicant1skill & wantedskill) * 100 / 6))
print("Applicant 2 skill match : {:.2f}%".format(len(applicant2skill & wantedskill) * 100 / 6))
print("Applicant 3 skill match : {:.2f}%".format(len(applicant3skill & wantedskill) * 100 / 6))
print("Applicant 4 skill match : {:.2f}%".format(len(applicant4skill & wantedskill) * 100 / 6))
print("Applicant 5 skill match : {:.2f}%".format(len(applicant5skill & wantedskill) * 100 / 6))
