import pymongo
import dns
import csv
from datetime import datetime
import socket


# update set column = ? where....
def updateData():
    with pymongo.MongoClient(cloudDatabase) as conn:
        db = conn.get_default_database()
        # db = conn.get_database('เลือกDatabase')
        # update_one(where, set), update_many(where, set)
        where = {'student_id': '1913110522'}
        setTo = {'$set': {'major': 'DC'}}
        res = db.students.update_one(where, setTo)
        print("{} -- {}".format(res.matched_count,
                                res.modified_count))  # matched_count เจอกี่รายการ,modified_count แก้ไขกี่รายการ


def deleteData():  # delete in database
    with pymongo.MongoClient(cloudDatabase) as conn:
        db = conn.get_database('Tni')
        # .delete_one(where), .delete_many(where)
        where = {'major': 'MT'}
        res = db.students.delete_many(where)
        print("{}".format(res.deleted_count))


def cleaning_fee():
    with pymongo.MongoClient(cloudDatabase) as conn:
        db = conn.get_database('sample_airbnb')
        # number_of_reviews > 150 and have cleaning_fee
        con1 = {'number_of_reviews': {'$gt': 150}}
        con2 = {'cleaning_fee': {'$exists': True}}
        where = {'$and': [con1, con2]}
        cursor = db.listingsAndReviews.find(where)
        found = db.listingsAndReviews.count_documents(where)
        print("Found {:,}".format(found))
        no = 1
        for i in cursor:
            print("{}.) {}  {}".format(no, i['name'], i['listing_url']))
            print("{}".format(i['cleaning_fee']))
            no += 1


def airbnb_no_of_reviews():
    with pymongo.MongoClient(cloudDatabase) as conn:
        db = conn.get_database('sample_airbnb')
        cursor = db.listingsAndReviews.find()
        for i in cursor:
            print("-" * 40)
            print("NAME = {} \nTOTAL COMMENT : {}".format(i['name'], len(i['reviews'])))


def see_reviews():
    with pymongo.MongoClient(cloudDatabase) as conn:
        db = conn.get_database('sample_airbnb')
        name = input("Please Enter AirBnb Name : ")
        where = {'name': name}
        cursor = db.listingsAndReviews.find(where)
        print("-" * 60)
        print("NAME : {}".format(name))
        no = 1
        for i in cursor:
            print("TOTAL {} COMMENT".format(len(i['reviews'])))
            print("-" * 60)
            for a in i['reviews']:
                print("{}.) {}".format(no, a['comments']))
                print("")
                no += 1


def export_air_bnb_location():
    with pymongo.MongoClient(cloudDatabase) as conn:
        db = conn.get_database('sample_airbnb')
        cursor = db.listingsAndReviews.find()
        data = [['Place', 'Country', 'Latitude', 'Longtitude']]
        for i in cursor:
            data.append([i['name'], i['address']['country'], i['address']['location']['coordinates'][1],
                         i['address']['location']['coordinates'][0]])

        with open(file='myfile/location', mode='w', encoding='utf8', newline="") as f:
            fw = csv.writer(f, delimiter=",")
            fw.writerows(data)
            print('done')


def show_average_score():
    with pymongo.MongoClient(cloudDatabase) as conn:
        db = conn.get_database('sample_restaurants')
        id = input("กรอก retaurant_id ที่ต้องการดูคะเเนนเฉลี่ย : ")
        where = {'restaurant_id': id}
        cursor = db.restaurants.find(where)
        # 40356018
        sum = 0
        count = 0
        for i in cursor:
            print(i['name'])
            print("")
            for a in i['grades']:
                count = count + 1
                print("Score {} = {}".format(count, a['score']))
                sum = sum + a['score']

        print("")
        print("AVERAGE = {:.2f}".format(sum / count))


def comment_mflex():
    with pymongo.MongoClient(cloudDatabase) as conn:
        db = conn.get_database('sample_mflix')
        mname = input("หนังที่ต้องการ Comment : ")
        where = {'title': mname}
        cursor = db.movies.find(where)
        id = ""
        for i in cursor:
            id = i['_id']
        print(id)
        name = input('ชื่อ : ')
        lastname = input('นามสกุล : ')
        mail = input("E-mail : ")
        comment = input("Comment ว่า : ")
        data = {'date': datetime.now(), 'email': mail, 'movie_id': id, 'name': name + ' ' + lastname, 'text': comment}
        db.comments.insert_one(data)
        print("")
        print("SUCCESSFULLY COMMENTED")


if __name__ == '__main__':
    cloudDatabase = "mongodb+srv://myAccount:peerapol1@cluster0.ws1ng.mongodb.net/Tni?retryWrites=true&w=majority"
    # cloudDatabase = "mongodb+srv://test:e8KEYpEiuQFuurV3@cluster0.hf3dm.mongodb.net/Tni?retryWrites=true&w=majority"
    # updateData()
    # deleteData()
    # cleaning_fee()
    # airbnb_no_of_reviews()
    # see_reviews()
    export_air_bnb_location()
    #show_average_score()
    # comment_mflex()
