import pymongo
from datetime import datetime
import socket
import dns
import csv


def insertData():
    with pymongo.MongoClient(cloudDatabase) as conn:
        db = conn.get_database('Tni')
        # db.students.insert_one({})
        # db.students.insert_many([{},{},..])
        mydata = {'student_id': '1913110522', 'name': 'Peerapol', 'lastname': 'Boonkoom',
                  'physical_data': {'weight': 170, 'height': 50}, 'major': 'IT', 'year': 3, 'gpax': 3.19,
                  'from': ip_address, 'updated': datetime.now()}
        db.students.insert_one(mydata)
        print("Insert Successful")


def useStudents():
    with pymongo.MongoClient(cloudDatabase) as conn:
        db = conn.get_default_database()
        condition = {'major': 'IT'}  # {'major':{'$eq':'IT'}}
        cursor = db.students.find(condition)
        found = db.students.count_documents(condition)
        print("Found = {} records".format(found))
        for i in cursor:
            print("Name : {}".format(i['name']))


def bmi():
    with pymongo.MongoClient(cloudDatabase) as conn:
        db = conn.get_default_database()
        cursor = db.students.find()
        for i in cursor:
            print("Name : {} {}".format(i['name'], int(i['physical_data']['weight']) / (
                    (int(i['physical_data']['height']) / 100) ** 2)))


def export_students():
    with pymongo.MongoClient(cloudDatabase) as conn:
        db = conn.get_database('Tni')
        cursor = db.students.find()
        data = [['student_id', 'name', 'lastname', 'physical_data', 'major', 'year', 'gpax', 'from', 'updated']]
        for i in cursor:
            data.append(
                [i['student_id'], i['name'], i['lastname'], i['physical_data'], i['major'], i['year'], i['gpax'],
                 i['from'], i['updated']])

    with open(file='myfile/student', mode='w', encoding='utf8', newline="") as f:
        fw = csv.writer(f, delimiter=",")
        fw.writerows(data)
        print('done')


if __name__ == '__main__':
    cloudDatabase = "mongodb+srv://myAccount:peerapol1@cluster0.ws1ng.mongodb.net/Tni?retryWrites=true&w=majority" #ของตัวเอง
    #cloudDatabase = "mongodb+srv://test:e8KEYpEiuQFuurV3@cluster0.hf3dm.mongodb.net/Tni?retryWrites=true&w=majority"
    hostname = socket.gethostname()
    ip_address = socket.gethostbyname(hostname)
    # print("{} -- {}".format(hostname, ip_address))
    # print("{}".format(datetime.now()))
    # insertData()
    # useStudents()
    # bmi()
    export_students()
