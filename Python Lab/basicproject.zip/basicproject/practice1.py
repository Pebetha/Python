# คำนวณ BMI
w = float(input("weight : "))
h = float(input("height : "))
bmi = w / ((h / 100) ** 2)
print("Your bmi is {:.2f} ".format(bmi))
# print("Your bmi is {:<.2f} ".format(bmi))หัวลูกศรชี้ทางไหนชิดทางนั้นปกติตัวเลขจะชิดขวา
# print("Your bmi is {:30,.2f} ".format(bmi))เว้น30ช่องแล้วก็มี ,
