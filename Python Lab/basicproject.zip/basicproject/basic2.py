# ตัวแปร
age = 30
age = age + 10
print("AGE = {} Type = {}".format(age, type(age)))
age = 12.5
age = 12.5 + 0.7
print("AGE = {} Type = {}".format(age, type(age)))
age = "ten"
print("AGE = {} Type = {}".format(age, type(age)))
