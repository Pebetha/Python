# รับค่าทางคีย์บอร์ด
# int , float , str
birth_year = int(input("กรุณากรอกปีเกิด : "))
# print("{}".format(type(birth_year)))
# age = 2564 - int(birth_year)
age = 2564 - birth_year
print("Your birthyear is {}".format(birth_year))
print("Age = {}".format(age))
