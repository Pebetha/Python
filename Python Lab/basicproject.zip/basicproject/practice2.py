# Slide43
product = float(input("Enter Price of Product  : "))
amount = int(input("Enter Amount of Product : "))
print("----------------------------------------")
print("Price\t     : {:10,.2f} Baht".format(product))
print("Amount\t\t : {:10} ".format(amount))
sub = product * amount
print("Subtotal\t : {:10,.2f} Baht".format(sub))
print("----------------------------------------")
vat = (sub * 7) / 100
print("Vat (7%)\t : {:10,.2f} Baht".format(vat))
total = sub + vat
print("Grand total\t : {:10,.2f} Baht".format(total))
print("----------------------------------------")
