# เขียนวันพุธที่ 16 มิถุนายน 2564
print("Peet\n")
print("\tThai Nichi")
print("Thailand" * 50)
# พิมพ์ไทยแลน50ครั้ง
