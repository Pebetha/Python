# print("Adisak" , "Suasaming" , "Thai-Nichi" , sep="*")

def calWeight(*dataweight, unit):
    # print("{}".format(dataweight))
    # print("{}".format(type(dataweight)))
    sum = 0
    for i in dataweight:
        sum += i
    avg = sum / len(dataweight)
    avgWithUnit = "{:,.2f} {} ".format(avg, unit)
    sumWithUnit = "{:,.2f} {} ".format(sum, unit)
    return avg, sum, avgWithUnit, sumWithUnit


A, S, AU, SU = calWeight(78, 34, 56, 23, 23, 14, 56, 76, 12, unit="kg")
print("{} -- {} ".format(A, S))
print("{} -- {} ".format(AU, SU))
# calWeight(78, 34, 56, 23, 13, 56, 89, 54, 32)
