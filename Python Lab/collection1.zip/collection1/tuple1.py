# tuple เก็บได้หมดแม้ว่าชนิดข้อมูลจะต่างกัน
data1 = 12, 34, 1, 7, 16, 16
data2 = (23, 56, 12, 34, 89, 90, 5.6, 'Adisak')
# print("{}".format(data1))
# print("{}".format(data2))
# print("{}".format(type(data1))
print("{}".format(data1))
print("{}".format(data1[4]))
print("Member {}".format(len(data1)))
print("Member {}".format(data1.__len__()))
print("-" * 10)
for i in range(len(data1)):
    print("{}".format(data1[i]))
print("-" * 10)
for i in data1:  # for -each
    print("{}".format(i))
print("-" * 10)
