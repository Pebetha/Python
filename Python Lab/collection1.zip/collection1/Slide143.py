# Slide143
import math

x1 = int(input('X1 : '))
y1 = int(input('Y1 : '))
x2 = int(input('X2 : '))
y2 = int(input('Y2 : '))
point1 = x1, y1
point2 = x2, y2
print("{}".format(point1))
print("{}".format(point2))
x = math.sqrt(((x2 - x1) ** 2) + ((y2 - y1) ** 2))
print("Distance between two points = {:.2f}".format(x))
