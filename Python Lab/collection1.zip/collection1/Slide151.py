def checkNumber(*number, see):
    max = 0.00
    min = 999.00
    sum = 0
    low = 0
    above = 0
    if see == "max-min":
        for i in number:
            if i > max:
                max = i
            if i < min:
                min = i
        return max, min

    if see == "ab-bl-av":
        for i in number:
            sum = sum + i
        avg = sum / len(number)
        for i in number:
            if i > avg:
                above = above + 1
            if i < avg:
                low = low + 1
        return above, low


x, y = checkNumber(17, 22, 35, 55, 67, 38, 98, 109, 10, 5, 77, see="max-min")
print("MAXIMUN = {}\nMINIMUM = {}".format(x, y))
x, y = checkNumber(12, 99, 34, 67, 21, 98, 13, see="ab-bl-av")
print("ABOVE AVERGAE = {}\nBELOW AVERAGE = {}".format(x, y))
