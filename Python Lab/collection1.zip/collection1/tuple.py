# python collection(array)
# 1.Tuple
# 2. List
# 3. Set
# 4. Dictionnary
