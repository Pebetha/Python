# Slide145
weight = (62.5, 78, 50, 42, 84, 65.5, 48, 53.5, 43)
Max = 0
Min = 0
total = 0
above = 0
below = 0
equal = 0
for i in weight:
    if Max == 0 and Min == 0:
        Max = i
        Min = i
    if Max < i:
        Max = i
    if Min > i:
        Min = i
    total += i
avr = total / len(weight)
for i in weight:
    if i > avr:
        above += 1
    if i < avr:
        below += 1
    if i == avr:
        equal += 1
print("Maximum weight of {} persons = {}".format(len(weight), Max))
print("Minimum weight of {} persons = {}".format(len(weight), Min))
print("Average weight of {} persons = {:.2f}".format(len(weight), avr))
print("No. of weight above average    = {}".format(above))
print("No. of weight below average    = {}".format(below))
print("No. of weight equal to average = {}".format(equal))
