# function declaration def คือ การเพิ่ม function
import math


def line1():
    print("-" * 35)


def line2(ch):  # line2('#')
    print("{}".format(ch) * 50)


def line3(ch, num):
    print("{}".format((ch) * num))


def calbmi(w, h):
    bmi = w / math.pow(h, 2)
    return bmi


def createEmail(N, L):
    email = "{}.{}_st@tni.ac.th".format(L[0:2], N).lower()
    return email
