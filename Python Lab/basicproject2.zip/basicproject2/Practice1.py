import MyLibrary as ml

Name = input(" Input your name : ")
Lastname = input(" Input your lastname : ")
print("E-mail of TNI is : {}".format(ml.createEmail(Name, Lastname)))
