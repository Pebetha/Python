# Grand Total Calculation
# from MyLibrary import line1, line2, line3 วิธีทimportที่1โดยเอามาบ้างmetodได้
# import MyLibrary วิธีทimportที่2เอามาทั้งไฟล์
import MyLibrary as ml  # วิธีทimportที่3โดยการตั้งชื่อ

price = float(input("Enter Price of Product  : "))
amount = int(input("Enter Amount of Product : "))
# print("-" * 35)
ml.line1()
print("{0:<14}:{1:>13,.2f} Baht".format("PRICE", price))
print("{0:<14}:{1:>13,} Baht".format("AMOUNT", amount))
subtotal = price * amount
print("{0:<14}:{1:>13,.2f} Baht".format("SUBTOTAL", subtotal))
# print("-" * 35)
ml.line2('#')
print("{0:<14}:{1:>13,.2f} Baht".format("VAT (7%)", subtotal * .07))
print("{0:<14}:{1:>13,.2f} Baht".format("GRAND TOTAL", subtotal * 1.07))
# print("-" * 35)
ml.line3('$', 45)
