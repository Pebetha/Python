Name = "Thai-Nichi"
# Slice -> Start / Stop / Stepเพิ่มขึ้นที่ละเท่าไหร่
print("{}".format(Name[0]))
print("{}".format(Name[0:5]))
print("{}".format(Name[2:8]))
print("{}".format(Name[2:8:2]))
