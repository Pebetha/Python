# in
score = [99, 98, 88, 77, 67, 56, 56, 30, 21, 20]
check = 99 in score  # True , False
print("{}".format(check))
if 99 in score:
    print("{}".format(check))
