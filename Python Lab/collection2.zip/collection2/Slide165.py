# Slide165
Listdata = []
for i in range(3):
    x = input("Point {} (x,y) : ".format(i + 1))
    y = x.split(' ')
    y = [(int(i)) for i in y]
    Listdata.append(tuple(y))
print("{}".format(Listdata))
x1 = Listdata[0][0]
y1 = Listdata[0][1]
x2 = Listdata[1][0]
y2 = Listdata[1][1]
x3 = Listdata[2][0]
y3 = Listdata[2][1]
area = ((x1 * (y2 - y3)) - (x2 * (y1 - y3)) - (x3 * (y1 - y2))) / 2
print("{}".format(area))
