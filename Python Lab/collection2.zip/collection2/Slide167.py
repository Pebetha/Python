# Slide167

flowers = ["Sun flower", "Ivy", "Jusmine", "Lily"]
while True:
    search = input("Enter flower that you want to search : ").lower()
    newsearch = ""
    if search == "break":
        break
    for i, j in enumerate(search):
        if i == 0:
            j = j.upper()
        if i > 0:
            j = j.lower()
        newsearch += j
    print("{}".format(newsearch in flowers))
