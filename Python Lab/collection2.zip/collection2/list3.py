# Slicing start, stop , step
score = [99, 98, 88, 77, 67, 56, 56, 30, 21, 20]
print("{}".format(score))
print("{}".format(score[2]))
print("{}".format(score[2:7]))
print("{}".format(score[2:7:2]))
newScore = score[2:7:2]
