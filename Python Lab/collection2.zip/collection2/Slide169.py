# Slide169
rude_word = ["damn", "hell", "ass", "piss", "silly", "idiotic"]
while True:
    check = False
    comment = input("Please comment our service : ").lower()
    checkcomment = comment.split(" ")
    for i in checkcomment:
        if i in rude_word:
            print("Cannot show [{}]".format(comment))
            check = True
    if not check:
        print("Can show [{}]".format(comment))
        break
