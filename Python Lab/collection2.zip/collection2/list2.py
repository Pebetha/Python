# เข้า แก้ไข เพิ่มข้อมูล
score = [10, 56, 67, 88, 98, 30, 21]
print("{}".format(score))
score[0] = 20
print("{}".format(score))
score.append(56)  # เพิ่มlistที่ละตัว
print("{}".format(score))
score = score + [77, 88, 99]
print("{}".format(score))
del score[3]
print("{}".format(score))
score.sort()  # เรียงจากน้อยไปมาก
print("{}".format(score))
score.sort(reverse=True)  # เรียงจากมากไปน้อย
print("{}".format(score))
