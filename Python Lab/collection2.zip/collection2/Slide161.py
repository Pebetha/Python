# Slide161
def line():
    print("-" * 30)


flowers = ["Sun flower", "Ivy", "Jusmine", "Lily"]
flowers.sort()
for i, v in enumerate(flowers):
    print("{}.) {}".format(i + 1, v))
line()
